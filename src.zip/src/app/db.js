const mysql = require("mysql");

const connection = mysql.createConnection({
  host: "localhost",
  user: "taqirwax_click_fit",
  password: "^Dwu#tKd*S7*R4^%",
  database: "taqirwax_click_fit"
});

module.exports = connection;
